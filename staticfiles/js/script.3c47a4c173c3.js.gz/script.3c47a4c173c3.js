console.log("Trekkie Blog JavaScript loaded.");

// JavaScript for Django admin actions with shift-click support.
// Based on staticfiles/admin/js/actions.js from Django 4.2.7